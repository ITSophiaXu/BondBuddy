CREATE OR REPLACE FUNCTION bb_material_lifecycle_input_keys(p_owner text,p_project text,p_revision integer)
RETURNS TABLE(source_project_id text,material_id text,material_version integer,lifecycle_key bigint)
LANGUAGE sql STABLE AS $$
  WITH input AS (
    SELECT manifest,material_versions FROM bb_input_revisions
    WHERE owner_user_id=p_owner AND project_id=p_project AND revision=p_revision
  ), local_refs AS (
    SELECT pin FROM input i CROSS JOIN LATERAL jsonb_array_elements(
      CASE WHEN jsonb_typeof(i.material_versions)='array' THEN i.material_versions ELSE '[]'::jsonb END) refs(pin)
    UNION
    SELECT pin FROM input i CROSS JOIN LATERAL jsonb_array_elements(
      CASE WHEN jsonb_typeof(i.manifest->'materials')='array' THEN i.manifest->'materials' ELSE '[]'::jsonb END) refs(pin)
  ), candidate_refs AS (
    SELECT p_project AS project_id,pin FROM local_refs
    UNION ALL
    SELECT pin->>'source_project_id',pin FROM input i
    CROSS JOIN LATERAL jsonb_array_elements(
      CASE WHEN jsonb_typeof(i.material_versions)='array' THEN i.material_versions ELSE '[]'::jsonb END) refs(pin)
    WHERE i.manifest->>'version' IN ('m4-document-input-v1','m4-qa-input-v1')
      AND jsonb_typeof(pin->'source_project_id')='string'
      AND jsonb_typeof(pin->'sha256')='string' AND pin->>'sha256' ~ '^[0-9A-Fa-f]{64}$'
  ), parsed_refs AS (
    SELECT project_id,pin->>'material_id' AS id,
      CASE WHEN jsonb_typeof(pin->'material_version')='number'
        THEN (pin->>'material_version')::numeric END AS version_number
    FROM candidate_refs WHERE jsonb_typeof(pin->'material_id')='string'
  ), material_refs AS (
    SELECT project_id,id,
      CASE WHEN version_number BETWEEN 1 AND 2147483647 AND version_number=trunc(version_number)
        THEN version_number::integer END AS version
    FROM parsed_refs
  )
  SELECT project_id,id,version,bb_material_lifecycle_lock_key(p_owner,project_id,id,version)
  FROM material_refs WHERE version IS NOT NULL
$$;

CREATE OR REPLACE FUNCTION bb_assert_material_lifecycle_available(p_owner text,p_project text,p_revision integer)
RETURNS void LANGUAGE plpgsql VOLATILE AS $$
DECLARE key_to_lock bigint;
BEGIN
  IF current_setting('transaction_isolation')<>'read committed' THEN
    RAISE EXCEPTION 'material lifecycle coordination requires READ COMMITTED isolation'
      USING ERRCODE='23514',CONSTRAINT='bb_material_lifecycle_isolation';
  END IF;
  FOR key_to_lock IN SELECT DISTINCT lifecycle_key
    FROM bb_material_lifecycle_input_keys(p_owner,p_project,p_revision) ORDER BY lifecycle_key
  LOOP
    PERFORM pg_advisory_xact_lock(key_to_lock);
  END LOOP;
  -- Lock speculative tuples too, but preserve the exact original candidate check
  -- after every wait so a fake reference does not create a new admission rule.
  IF EXISTS(
    SELECT 1 FROM bb_material_lifecycle_input_keys(p_owner,p_project,p_revision) k
    JOIN bb_material_versions m ON m.owner_user_id=p_owner AND m.project_id=k.source_project_id
      AND m.id=k.material_id AND m.version=k.material_version
    JOIN bb_input_revisions i ON i.owner_user_id=p_owner AND i.project_id=p_project AND i.revision=p_revision
    JOIN bb_storage_tombstones t ON t.object_kind='material' AND t.owner_user_id=p_owner
      AND t.project_id=m.project_id AND t.material_id=m.id AND t.material_version=m.version
    WHERE ((m.project_id=p_project
        AND (i.material_versions @> jsonb_build_array(jsonb_build_object('material_id',m.id,'material_version',m.version))
          OR i.manifest->'materials' @> jsonb_build_array(jsonb_build_object('material_id',m.id,'material_version',m.version))))
      OR (i.manifest->>'version' IN ('m4-document-input-v1','m4-qa-input-v1')
        AND i.material_versions @> jsonb_build_array(jsonb_build_object(
          'source_project_id',m.project_id,'material_id',m.id,'material_version',m.version,'sha256',btrim(m.sha256::text)))))
      AND (t.state='purged' OR EXISTS(SELECT 1 FROM bb_storage_purge_starts s WHERE s.tombstone_id=t.id))
  ) THEN
    RAISE EXCEPTION 'material purge has already started; its original bytes cannot acquire a new execution pin'
      USING ERRCODE='23514',CONSTRAINT='bb_material_purge_barrier';
  END IF;
END $$;