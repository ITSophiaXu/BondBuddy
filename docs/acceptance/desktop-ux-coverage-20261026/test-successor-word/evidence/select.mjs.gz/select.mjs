import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';
const root = process.cwd(), base = resolve('.local/test-successor-v2-20261027');
const target = resolve('docs/acceptance/desktop-ux-coverage-20261026/test-successor-word');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = path => JSON.parse(readFileSync(path, 'utf8'));
const runs = readdirSync(base, { withFileTypes: true }).filter(entry => entry.isDirectory())
  .flatMap(entry => { try { const directory = join(base, entry.name); return [{ directory, summary: json(join(directory, 'summary.json')) }]; } catch { return []; } });
const latest = mode => runs.filter(run => run.summary.mode === mode).sort((a,b) => a.summary.startedAt.localeCompare(b.summary.startedAt)).at(-1);
const api = latest('api'), correction = latest('api-assertion'), worker = latest('worker');
if (!api?.summary.sourcesEqual || !correction?.summary.success || !worker?.summary.success) throw Error('Final completed source-stable runs are required');
const counts = (run, name) => {
  const log = readFileSync(join(run.directory, `${name}.log`), 'utf8');
  const count = key => Number(new RegExp(`(?:ℹ |# )${key} (\\d+)`, 'u').exec(log)?.[1] ?? NaN);
  const result = { tests: count('tests'), pass: count('pass'), fail: count('fail'), skip: count('skipped') };
  if (Object.values(result).some(Number.isNaN)) throw Error('Missing complete test counters');
  return result;
};
const before = json(join(api.directory, 'sources-after.json')), after = json(join(correction.directory, 'sources-before.json'));
const changes = after.filter(item => before.find(previous => previous.path === item.path)?.sha256 !== item.sha256).map(item => item.path);
const expected = ['apps/api/dist/artifact-execution.pg.test.js', 'apps/api/src/artifact-execution.pg.test.ts'];
if (JSON.stringify(changes.sort()) !== JSON.stringify(expected)) throw Error(`Unexpected API changes: ${changes}`);
const manifest = json(join(worker.directory, 'sources-after.json'));
const current = manifest.map(item => { const bytes = readFileSync(resolve(item.path)); return { ...item, bytes: bytes.length, sha256: sha(bytes) }; });
const mismatches = current.filter((item,index) => item.sha256 !== manifest[index].sha256 || item.bytes !== manifest[index].bytes).map(item => item.path);
const apiFinal = json(join(correction.directory, 'sources-after.json'));
const apiInWorker = apiFinal.every(item => manifest.some(value => value.path === item.path && value.sha256 === item.sha256 && value.bytes === item.bytes));
const check = { checkedAt: new Date().toISOString(), entries: manifest.length, mismatches, apiFinalMatchesWorker: apiInWorker };
writeFileSync(join(base, 'final-source-check.json'), JSON.stringify(check, null, 2) + '\n');
if (mismatches.length || !apiInWorker) throw Error('Final sources differ');
const apiPg = counts(api, 'pg'), apiFixed = counts(correction, 'pg');
if (apiPg.fail !== 1 || apiFixed.tests !== 6 || apiFixed.fail || apiFixed.skip) throw Error('Unexpected correction scope');
const selection = { version: 1, baseline: '5d1f3795d4ecd9c55bb924510dbcc719a0743392',
  selected: {
    apiPure: { run: relative(base,api.directory), ...counts(api,'pure'), sourceEntries: api.summary.sourceEntries },
    apiPg: { originalRun: relative(base,api.directory), original: apiPg,
      replacementRun: relative(base,correction.directory), replacementFile: 'artifact-execution.pg.test.js', replacement: apiFixed,
      adopted: { pass: apiPg.pass + 1, fail: 0, skip: apiPg.skip }, accounting: '151 unaffected passes plus the corrected six-test file; repeated passes counted once',
      sourceEntries: correction.summary.sourceEntries, onlyBetweenRoundChanges: changes },
    workerPure: { run: relative(base,worker.directory), ...counts(worker,'pure'), sourceEntries: worker.summary.sourceEntries },
    workerPg: { run: relative(base,worker.directory), ...counts(worker,'pg'), sourceEntries: worker.summary.sourceEntries }
  },
  notAdoptedAsFinal: runs.filter(run => run !== api && run !== correction && run !== worker).map(run => ({
    run: relative(base,run.directory), mode: run.summary.mode, success: run.summary.success, sourcesEqual: run.summary.sourcesEqual,
    note: 'Retained complete failure/output; repeated passes are not added to final counts' })),
  finalSourceCheck: check,
  skipLimits: ['Three new Linux-contained provider cases skipped on Windows',
    'Two existing Linux-only symlink cases skipped on Windows', 'One existing test-channel Word/Azurite case skipped without Azurite'],
  environment: { template: 'bb_successor_word_final_20261027', port: 15542, postgres: '16.14', node: worker.summary.node,
    python: '3.12.14', pythonDocx: '1.2.0', lxml: '6.1.1', pythonRuntimeFrozen: false },
  productDecision: 'B1 chosen; public quote confirmation and supplementary billing are not implemented in this slice',
  limits: ['Synthetic provider seam is not Linux containment or external supplier acceptance', 'No complete desktop G03 or overall coverage completion claim', 'No push, PR, merge or deployment'] };
writeFileSync(join(target,'selection.json'), JSON.stringify(selection,null,2) + '\n');
process.stdout.write(JSON.stringify(selection.selected) + '\n');
