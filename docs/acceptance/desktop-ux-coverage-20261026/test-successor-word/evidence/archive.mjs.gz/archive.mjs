import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { gzipSync, gunzipSync } from 'node:zlib';

const root = process.cwd();
const source = resolve('.local/test-successor-v2-20261027');
const target = resolve('docs/acceptance/desktop-ux-coverage-20261026/test-successor-word');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const baseline = '5d1f3795d4ecd9c55bb924510dbcc719a0743392';
const files = [];
function walk(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) walk(path);
    else if (entry.isFile() && /\.(json|log|txt|mjs)$/.test(entry.name)) files.push(path);
  }
}
walk(source);
files.push(resolve('db/migrations/0136_test_successor_word_delivery.sql'));
const diagnostic = resolve('.local/validation/worker-supplement-v2-20261027-diagnostics.json');
if (existsSync(diagnostic)) files.push(diagnostic);
mkdirSync(join(target, 'evidence'), { recursive: true });
const entries = [];
for (const path of files.sort()) {
  const name = relative(root, path).replaceAll('\\', '/');
  const scoped = relative(source, path);
  const archivedName = path === diagnostic ? 'worker-diagnostics.json' : scoped.startsWith('..') ? name : scoped;
  const destination = join(target, 'evidence', archivedName + '.gz');
  const bytes = readFileSync(path), compressed = gzipSync(bytes, { level: 9 });
  mkdirSync(resolve(destination, '..'), { recursive: true });
  writeFileSync(destination, compressed);
  if (!gunzipSync(readFileSync(destination)).equals(bytes)) throw Error(`Archive round trip failed: ${name}`);
  entries.push({ source: name, path: relative(target, destination).replaceAll('\\', '/'),
    bytes: bytes.length, sha256: sha(bytes), gzip_bytes: compressed.length, gzip_sha256: sha(compressed) });
}
const selection = readFileSync(join(target, 'selection.json'));
const manifest = { version: 1, baseline, archivedAt: new Date().toISOString(),
  readme_sha256: sha(readFileSync(join(target, 'README.md'))), selection_sha256: sha(selection), entries };
writeFileSync(join(target, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
process.stdout.write(JSON.stringify({ entries: entries.length, sourceBytes: entries.reduce((sum, item) => sum + item.bytes, 0),
  compressedBytes: entries.reduce((sum, item) => sum + item.gzip_bytes, 0), manifestSha256: sha(readFileSync(join(target, 'manifest.json'))) }) + '\n');
