import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Client } from 'pg';
const url = 'postgresql://bb_successor_test@127.0.0.1:15542/bb_successor_word_final_20261027';
const client = new Client({ connectionString: url });
await client.connect();
let audit;
try {
  const server = (await client.query(`SELECT current_database(),current_user,version(),inet_server_port(),
    pg_postmaster_start_time(),current_setting('data_directory') AS data_directory`)).rows[0];
  const migration = (await client.query('SELECT count(*)::int AS count,max(filename) AS latest FROM bb_schema_migrations')).rows[0];
  const databases = (await client.query('SELECT datname FROM pg_database ORDER BY datname')).rows.map(row => row.datname);
  const clients = (await client.query("SELECT pid,datname,usename,application_name,state,backend_start FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid() ORDER BY pid")).rows;
  audit = { checkedAt: new Date().toISOString(), server, migration, databases, otherClients: clients };
  writeFileSync(resolve('.local/test-successor-v2-20261027/database-final-audit.json'), JSON.stringify(audit, null, 2) + '\n');
  assert.equal(server.inet_server_port, 15542);
  assert.equal(new Date(server.pg_postmaster_start_time).toISOString(), '2026-10-26T23:54:05.711Z');
  assert.equal(server.data_directory.replaceAll('\\','/').toLowerCase(), resolve('.local/test-successor-postgres/data').replaceAll('\\','/').toLowerCase());
  assert.equal(migration.count, 135); assert.equal(migration.latest, '0136_test_successor_word_delivery.sql');
  assert.deepEqual(databases, ['bb_successor_template_20261027', 'bb_successor_word_final_20261027', 'postgres', 'template0', 'template1']);
  assert.equal(clients.length, 0, 'All test clients must close before server shutdown');
} finally { await client.end(); }
process.stdout.write(JSON.stringify(audit) + '\n');
