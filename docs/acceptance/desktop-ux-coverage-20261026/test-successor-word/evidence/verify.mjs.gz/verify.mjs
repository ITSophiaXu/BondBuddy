import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';

const require = createRequire(import.meta.url), root = process.cwd();
const mode = process.argv[2], database = process.argv[3];
if (!['api', 'api-assertion', 'worker'].includes(mode) || !database) throw Error('mode and exact test template URL required');
const out = resolve('.local/test-successor-v2-20261027', `${mode}-final-${new Date().toISOString().replaceAll(/[-:.]/g, '')}`);
mkdirSync(out, { recursive: false });
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const sourceRoots = ['apps/api/src', 'apps/api/dist', 'db/migrations', 'packages/contracts/src', 'packages/contracts/dist',
  'packages/domain/src', 'packages/domain/dist', 'packages/rule-applicability-context/src', 'packages/rule-applicability-context/dist',
  'packages/rule-pack-registry/src', 'packages/rule-pack-registry/dist',
  ...(mode === 'worker' ? ['apps/worker/src', 'apps/worker/dist', 'apps/worker/test-fixtures', 'python'] : [])];
const sourceFiles = ['package.json', 'package-lock.json', 'apps/api/package.json', 'apps/api/tsconfig.json',
  ...(mode === 'worker' ? ['apps/worker/package.json', 'apps/worker/tsconfig.json'] : [])];
function manifest() {
  const paths = [];
  function walk(dir) { for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '__pycache__', '.pytest_cache'].includes(entry.name)) continue;
    const path = join(dir, entry.name);
    if (entry.isDirectory()) walk(path); else if (entry.isFile()) paths.push(path);
  } }
  for (const dir of sourceRoots) walk(resolve(dir));
  paths.push(...sourceFiles.map(path => resolve(path)));
  return paths.map(path => { const bytes = readFileSync(path); return { path: relative(root, path).replaceAll('\\', '/'),
    bytes: bytes.length, sha256: sha(bytes) }; }).sort((a, b) => a.path.localeCompare(b.path));
}
const summary = { mode, startedAt: new Date().toISOString(), node: process.version, template: new URL(database).pathname,
  sourceRoots, sourceFiles, testEnvironment: Object.fromEntries(['BONDBUDDY_WORD_PYTHON', 'BONDBUDDY_TEST_PYTHON', 'BB_PYTHON_BIN',
    'BB_TEST_SSE_PG_INTEGRATION'].map(key => [key, process.env[key] ?? null])),
  invocations: [], sourceEntries: null, sourcesEqual: null };
function run(name, args) {
  process.stdout.write(`${name} started\n`);
  const start = Date.now(), result = spawnSync(process.execPath, args, { cwd: root, windowsHide: true,
    env: { ...process.env, BB_TEST_DATABASE_URL: database }, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  const log = `${result.stdout ?? ''}${result.stderr ?? ''}`;
  writeFileSync(join(out, `${name}.log`), log);
  const item = { name, args, exitCode: result.status, signal: result.signal, durationMs: Date.now() - start,
    error: result.error ? String(result.error) : null, logSha256: sha(Buffer.from(log)) };
  summary.invocations.push(item); writeFileSync(join(out, 'summary.json'), JSON.stringify(summary, null, 2));
  process.stdout.write(`${name} exit=${result.status}\n${log.split(/\r?\n/).slice(-12).join('\n')}\n`);
  return result.status === 0;
}
const built = run('build', [require.resolve('typescript/bin/tsc'), '-p', `apps/${mode === 'worker' ? 'worker' : 'api'}/tsconfig.json`]);
if (!built) { process.stdout.write(`${out}\n`); process.exit(1); }
const before = manifest(); writeFileSync(join(out, 'sources-before.json'), JSON.stringify(before));
let success = true;
if (mode === 'api-assertion') {
  success = run('pg', ['--test', '--test-concurrency=1', 'apps/api/dist/artifact-execution.pg.test.js']) && success;
} else if (mode === 'api') {
  success = run('pure', ['--test', '--test-concurrency=1', ...[
    'run-execution-input', 'run-execution-projection', 'run-execution-checkpoint', 'artifact-execution',
    'model-call-execution', 'run-execution-test-grant'].map(name => `apps/api/dist/${name}.test.js`)]) && success;
  success = run('pg', ['--test', '--test-concurrency=1', ...[
    'run-supplement-execution.pg.test', 'run-test-successor-word-sql.pg.test', 'run-working-files-successor.pg.test',
    'run-supplement-test-adoption.pg.test', 'run-working-files.pg.test', 'run-execution.pg.integration.test',
    'run-execution-business-snapshots.pg.test', 'run-execution-delivery.pg.test', 'artifact-execution.pg.test',
    'review-artifact-execution.pg.test', 'm4-artifact-execution.pg.test', 'review-editor-execution.pg.test',
    'review-report-execution.pg.test', 'model-call-execution.pg.integration.test', 'prompt-execution-boundary.pg.integration.test',
    'generated-word-delivery.test', 'word-delivery-artifact.test'].map(name => `apps/api/dist/${name}.js`)]) && success;
} else {
  success = run('pure', ['--test', '--test-concurrency=1', ...[
    'file-authoring-request.test', 'file-authoring-delivery.test', 'review-file-request.test',
    'review-file-stage.test', 'm4-document-request.test', 'm4-stages.test', 'run-execution-lease.test',
    'run-pipeline-error.test'].map(name => `apps/worker/dist/${name}.js`)]) && success;
  success = run('pg', ['--test', '--test-concurrency=1', ...[
    'run-supplement-execution-request.pg.test', 'test-channel-runtime.test',
    'worker-runtime-pipeline-seams.pg.integration.test', 'run-execution-consumers.pg.test',
    'execution-input-loaders.pg.test', 'authoring-pause.pg.test'
    ].map(name => `apps/worker/dist/${name}.js`)]) && success;
}
const after = manifest(); writeFileSync(join(out, 'sources-after.json'), JSON.stringify(after));
summary.sourceEntries = before.length; summary.sourcesEqual = JSON.stringify(before) === JSON.stringify(after);
summary.completedAt = new Date().toISOString(); summary.success = success && summary.sourcesEqual;
writeFileSync(join(out, 'summary.json'), JSON.stringify(summary, null, 2));
process.stdout.write(`${JSON.stringify(summary)}\n${out}\n`);
if (!summary.success) process.exitCode = 1;
