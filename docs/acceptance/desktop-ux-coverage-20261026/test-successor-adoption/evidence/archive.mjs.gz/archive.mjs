import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,readdir,mkdir,writeFile} from 'node:fs/promises';
import {dirname,join,relative,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync} from 'node:zlib';
const local=dirname(fileURLToPath(import.meta.url)),root=resolve(local,'../..');
const output=join(root,'docs/acceptance/desktop-ux-coverage-20261026/test-successor-adoption');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const selection=JSON.parse(await readFile(join(output,'selection.json'),'utf8'));
assert.deepEqual(selection.total,{pass:249,skip:2,fail:0});
for(const pair of selection.snapshotPairs){
  const before=await readFile(join(local,'runs',pair.before,'snapshot.json'));
  const after=await readFile(join(local,'runs',pair.after,'snapshot.json'));
  assert(before.equals(after),'Frozen source pair differs');
}
const final=JSON.parse(await readFile(join(local,'runs',selection.snapshotPairs[1].after,'snapshot.json'),'utf8'));
for(const entry of final){const bytes=await readFile(join(root,entry.path));assert.equal(sha(bytes),entry.sha256,entry.path);}
await writeFile(join(local,'final-source-check.json'),JSON.stringify({entries:final.length,
  snapshot_sha256:sha(await readFile(join(local,'runs',selection.snapshotPairs[1].after,'snapshot.json'))),
  checked_at:new Date().toISOString()},null,2)+'\n',{flag:'wx'});
const sources=[];
async function walk(directory){
  for(const entry of await readdir(directory,{withFileTypes:true})){
    const file=join(directory,entry.name);
    assert(!entry.isSymbolicLink(),'Never archive symlinks');
    if(entry.isDirectory())await walk(file);else if(entry.isFile())sources.push(file);
  }
}
await walk(join(local,'runs'));await walk(join(local,'versions'));
for(const name of ['verify.mjs','playwright.config.mjs','archive.mjs','startup-note.json','final-source-check.json'])sources.push(join(local,name));
await mkdir(join(output,'evidence'));
const manifest={version:1,baseline:selection.baseline,
  readme_sha256:sha(await readFile(join(output,'README.md'))),selection_sha256:sha(await readFile(join(output,'selection.json'))),entries:[]};
for(const file of sources.sort()){
  const source=relative(local,file).replaceAll('\\','/'),path='evidence/'+source+'.gz';
  const bytes=await readFile(file),stored=gzipSync(bytes,{level:9});
  await mkdir(dirname(join(output,path)),{recursive:true});await writeFile(join(output,path),stored,{flag:'wx'});
  manifest.entries.push({source,path,bytes:bytes.length,sha256:sha(bytes),gzip_bytes:stored.length,gzip_sha256:sha(stored)});
}
await writeFile(join(output,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({files:manifest.entries.length,final_source_entries:final.length,
  manifest_sha256:sha(await readFile(join(output,'manifest.json'))),output}));
