# 主站 PR1420 日志切换包

本包仅由 root 发布协调者执行，范围固定为主站 api、ops、web 和新增性能记录表。不停止 managed worker，不调用云 API，不恢复数据库，不修改任务、积分、模型策略，不包含备份归档本体。

固定基线：325c88248a41b33fccbb31d8262b57dab41d6659，06:39:02 UTC 完整快照，06:40:14 UTC 50 个挂载文件复核。新 ops 为 ddf5aa67...，保留其45个mount及最新 business-overlay.mjs。API吸收13个代码mount，保留node/global=8/8、max_nodes=2。动态budget_available允许true或false，原值只观测，不修改费用授权或策略。

候选：api e995a4928f4ec16048ac6b5c5cc136bf9582baf758bc71361cb08e20f4a9eb85；ops 22cc3fc268cad7bd2f77ae7f7e85680a939f2d06a2424c53a8aa11a5d0017a1d；web 1f49ae4d66c277e023901b2ec7b28b4f4a97e048d5110e35ad805ff9b80129be。三者均用 sha256: 前缀完整绑定，禁止旧v4 API。

## root 执行命令

先将压缩包安全解包到新的 staging 目录。运行目录必须尚不存在，父目录仅限 /var/lib/bondbuddy。下面两个路径均为本批新目录，不覆盖已有发布目录：

```sh
python3 -B /var/lib/bondbuddy/main1420-stage-20261116/run_main_cutover.py \
  --plan /var/lib/bondbuddy/main1420-stage-20261116/main-plan.bound.json

sudo -n python3 -B /var/lib/bondbuddy/main1420-stage-20261116/run_main_cutover.py \
  --plan /var/lib/bondbuddy/main1420-stage-20261116/main-plan.bound.json \
  --root /var/lib/bondbuddy/main1420-cutover-20261116 \
  --owner main1420-node8-20261116 \
  --backup-receipt /var/lib/bondbuddy/main1420-stage-20261116/backup.receipt.json \
  --sql-directory /var/lib/bondbuddy/main1420-stage-20261116 \
  --drain-timeout 300 --execute
```

未加 --execute 只校验计划。正式运行：先持有原inode的 config/deploy/migration 锁并写owned pending；prepare阶段只校验现有运行前像、生成配置和创建/删除从未启动的三个探针，不停业务。关闭入口前校验Caddy原值及API/web仅loopback绑定，逐个将已审查127.0.0.1:18090反代改为503并核验源站/公网。

仅等待主站 ops/upload 租约自然归零后取得原inode的 control-tick/TLS 锁。既存managed job、review租约、模型占用、ready sessions和queued记录仅观测，可由旧worker继续正常推进；不伪造managed drain，不冻结业务记录。只对API/ops发送TERM并确认干净退出，迁移前再次核对主站活动、策略和备份。ops最后启动，启动后允许其正常运行，不以它的新租约阻断最终HTTP与静态文件校验。失败恢复按ops/web/API逆序，只有真正停止ops的回滚步骤要求其自身租约自然归零；其余已证明兼容的主站组件可滚动恢复。

按序执行 canonical0185 → 独立ACL → API → web → ops。0185仅新增两张性能表和五个索引，并增加188→189的一条迁移记录；不ALTER业务表。新表外键可能短暂获取被引用表锁，设置1.5秒lock_timeout，不能获取即失败恢复。旧worker兼容新增表，主站发布无需停止运行中的worker任务。脚本没有UPDATE/DELETE/INSERT业务表，唯一DML是0185迁移台账新增；新增表外键只引用既有主键，旧表列、输入、账务和worker协议不变。ACL只授予四个既有worker角色的指定性能表列权限，不创建角色。旧主站代码可继续运行于新增schema上。

## 校验和恢复

- 23/2/4个主站目标文件逐个从运行容器有效路径核验，比较完整进程及HostConfig，保留所有无关mount、环境及网络。
- 真实HTTP健康检查、未认证用户对me/两条性能API的401检查、四个web文件的HTTP内容hash；开放后重复源站和公网检查。不声称已使用真实log_reader账号执行授权查询，不调用模型、不重跑业务任务。
- current-components使用文件前像CAS，仅更新api/ops/web的记录，其他组件及其他顶层字段原样保留。live检查和记录更新成功后清除owned pending、释放锁。
- 公开入口恢复前的失败：记录已执行步骤；未知Compose结果先按owner/image/config核对；未知迁移结果以持久XID、pg_xact_status、188/189台账及两表存在性核对，不自动重跑DDL。可恢复时启动同一原容器或按原配置回滚三组件，验证后恢复原入口。绝不恢复数据库或重放任务。
- 公开入口可能已恢复后的失败：只核对并完成当前候选版本，禁止自动切回旧消费者。只有向前校验完成后返回PASS_RECOVERED_FORWARD；否则保留owned pending并明确失败，供root继续处理。
- 连接中断保留pending、state和intent。先查state及实时状态；可用adapter的--serve --resume重新取得相同锁（hold_control需显式再次执行）。不得新建另一发布覆盖pending。

```sh
sudo -n python3 -B /var/lib/bondbuddy/main1420-stage-20261116/main-cutover-adapter.py \
  --plan /var/lib/bondbuddy/main1420-stage-20261116/main-plan.bound.json \
  --root /var/lib/bondbuddy/main1420-cutover-20261116 --owner main1420-node8-20261116 \
  --serve --resume
```

恢复接口为JSON行，先发送 {"action":"observe"}；支持hold_control、reconcile_migration、reconcile(role/kind)、restore_original(role)、rollback(role/guard)、verify、open_ingress、verify_live、commit_components、complete。guard必须绑定真实备份和当前owned关闭入口状态，不得构造虚假证明。

## 本地验证边界

25项离线测试涵盖固定版本/镜像/作用域拒绝、既存worker/queued/ready正常推进、主站ops/upload租约阻断、入口和bind保护、备份来源/全量decode、迁移未知结果、原像变化、归属、正常顺序、停机前失败、部分切换恢复和入口恢复后的向前完成。编译及plan验证通过。生产create-only配置探针及实际HTTP检查必须在本次root执行后才可称为通过。

Windows工作区0185含CRLF；包内使用已固定canonical LF字节，SHA20f7e159dca10fc86137f03e93d79a073c1787b4e6455693314a4f0d83dc347b。ACL按原字节封装，SHAd331cfdc523df6cbeba4daf47bd31df87bb32e72c6f98deb4081ee5e1f7c0a0b。两个SQL不可由终端重编码。