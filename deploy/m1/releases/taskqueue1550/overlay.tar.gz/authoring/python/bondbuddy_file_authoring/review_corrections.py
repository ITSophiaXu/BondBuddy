"""Trusted, deterministic review edits. No model/network calls, no document reconstruction for DOCX."""
import copy
import hashlib
import json
import re
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from .word_patch import Patcher, xml, serialized, paragraph_text, q, add_layout_comments
from .correction_findings import category_label, findings
from .correction_rounding import rounded_sum_limitation
from .correction_locator import CorrectionLocator
from bondbuddy_word_delivery.writer import normalize_old_revisions


def package(source, output):
    warnings = []
    if source.suffix.lower() == '.pdf':
        from docx import Document
        import pdfplumber
        document = Document()
        with pdfplumber.open(source) as pdf:
            for i, page in enumerate(pdf.pages):
                if i:
                    document.add_page_break()
                text = page.extract_text() or ''
                if not text.strip():
                    text = f'【待补充：原 PDF 第 {i+1} 页无法提取文字，请提供可检索 PDF 或 Word，并人工核对本页内容。】'
                    warnings.append(text)
                for line in text.splitlines():
                    document.add_paragraph(line)
        path = output / 'converted.docx'
        document.save(path)
        warnings.insert(0, '原稿为 PDF，已按可提取文字转换为 Word；版式、表格与分页可能不同，请对照原 PDF 核对。')
    else:
        path = source
    with ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 250_000_000:
            raise ValueError('REVIEW_SOURCE_TOO_LARGE')
        parts = {i.filename: z.read(i.filename) for i in z.infolist()}
    parts.setdefault('word/_rels/document.xml.rels', b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>')
    root = xml(parts['word/document.xml'])
    # The baseline is the effective text of the submitted version, not old deleted text.
    if any(root.iter(q('ins'))) or any(root.iter(q('del'))):
        normalize_old_revisions(root)
        warnings.append('原稿既有文字修订按接受后的有效文本作为本次基线，上传原件保持不变。')
    parts['word/document.xml'] = serialized(root)
    return parts, root, warnings


def write(path, parts):
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        for name, data in parts.items():
            z.writestr(name, data)


def build(source, request, output):
    output.mkdir(parents=True, exist_ok=True)
    sha = hashlib.sha256(source.read_bytes()).hexdigest()
    if sha != request['pin']['sha256']:
        raise ValueError('INPUT_REVISION_CONFLICT')
    parts, baseline, warnings = package(source, output)
    ps = list(baseline.iter(q('p')))
    paragraphs = [dict(id=f'p{i}', text=paragraph_text(p)) for i, p in enumerate(ps)]
    if request.get('editor'):
        previous = request['editor']
        if previous['source_sha256'] != sha or previous['paragraphs'] != paragraphs:
            raise ValueError('INPUT_REVISION_CONFLICT')
        issues = copy.deepcopy(previous['issues'])
        # Legacy snapshots discarded location. Recover only from the host's
        # hash-verified original report, with every original finding field equal.
        # Neither the old snapshot nor the user's saved decisions are rewritten.
        recovered = {i['id']: i for i in findings(request.get('original_report', ''))}
        for issue in issues:
            old = recovered.get(issue['id'])
            if not issue.get('original_location') and old and all(
                issue.get(key) == old.get(key) for key in
                ('title', 'category', 'original', 'replacement', 'reason', 'evidence', 'missing')
            ):
                issue['original_location'] = old['original_location']
    else:
        issues = findings(request['markdown'])
    scope = request.get('review_scope')
    if scope is not None:
        # A differential review is a closed set of original findings. The host
        # supplies these targets from its owner/hash-verified immutable editor.
        # Never silently discard extra suggestions or accept a reused ID over
        # unrelated source text. Refuse before writing any deliverable.
        ids = scope.get('finding_ids', [])
        targets = {i['id']: i for i in scope.get('targets', [])}
        reported = [i.get('source_finding_id') for i in issues]
        if (not ids or len(ids) != len(set(ids)) or set(targets) != set(ids)
            or len(reported) != len(ids) or set(reported) != set(ids)
            or any(i['original'] != targets[i['source_finding_id']]['original'] for i in issues)):
            raise ValueError('REVIEW_DIFFERENTIAL_SCOPE_INVALID')
        # The model cannot move the authorized quote to another occurrence by
        # supplying a different location label in its new report.
        for issue in issues:
            issue['original_location'] = targets[issue['source_finding_id']].get('original_location', '')
    if not issues:
        warnings.append('复核报告未提供可定位的问题条目，本次未自动修改正文。请阅读报告的覆盖范围并人工核对，不能据此认定未发现问题。')
    decisions = {d['id']: d for d in request.get('decisions', [])}
    if decisions and (len(decisions) != len(issues) or set(decisions) != {i['id'] for i in issues}):
        raise ValueError('REVIEW_DECISIONS_INVALID')
    locator = CorrectionLocator(baseline)
    for issue in issues:
        issue.update(decisions.get(issue['id'], {}))
        issue.update(applied=False, limitation='', paragraph_id=None)
        # Re-evaluate saved editors as well as new reports. Only an explicit
        # user's manual replacement may override this automated suggestion guard.
        if issue['decision'] == 'suggested':
            limitation = rounded_sum_limitation(issue['original'], issue['replacement'], issue['evidence'])
            if limitation:
                issue.update(uncertain=True, limitation=limitation)
        issue['paragraph_id'] = locator.locate(issue['original'], issue.get('original_location', ''))
        if not issue['paragraph_id']:
            issue['limitation'] = '原文无法唯一定位，保留原文；请下载后人工核对。'
    revised, clean = copy.deepcopy(baseline), copy.deepcopy(baseline)
    maps = [{f'p{i}': p for i, p in enumerate(r.iter(q('p')))} for r in (revised, clean)]
    # Group edits against the unchanged paragraph; reject overlapping edits explicitly.
    for paragraph in paragraphs:
        entries = [i for i in issues if i['paragraph_id'] == paragraph['id']]
        changes = []
        for issue in entries:
            if issue['decision'] == 'original' or (issue['decision'] == 'suggested' and (issue['uncertain'] or not issue['replacement'])):
                continue
            replacement = issue['manual_text'] if issue['decision'] == 'manual' else issue['replacement']
            if replacement == issue['original']:
                continue
            start = paragraph['text'].index(issue['original'])
            end = start + len(issue['original'])
            changes.append((start, end, issue))
        for start, end, issue in changes:
            if any(other is not issue and start < b and a < end for a, b, other in changes):
                issue['limitation'] = '多项建议修改了同一原文，请保留其中一项后重新保存。'
        selected = [(a,b,i) for a,b,i in changes if not i['limitation']]
        updated = paragraph['text']
        for a,b,issue in sorted(selected, key=lambda x:x[0], reverse=True):
            updated = updated[:a] + (issue['manual_text'] if issue['decision']=='manual' else issue['replacement']) + updated[b:]
        if selected and updated != paragraph['text']:
            # Work on copies: failure must not leave a partial patch in either output.
            candidates = [copy.deepcopy(m[paragraph['id']]) for m in maps]
            try:
                for candidate, tracked in zip(candidates, (True, False)):
                    Patcher(revised if tracked else clean, tracked).patch(candidate, paragraph['text'], updated)
            except ValueError:
                for _,_,issue in selected:
                    issue['limitation'] = '此处结构无法安全保留，未自动修改，请在 Word 中处理。'
            else:
                for m,candidate in zip(maps,candidates):
                    node=m[paragraph['id']]
                    node.getparent().replace(node,candidate)
                    m[paragraph['id']]=candidate
                for _,_,issue in selected:
                    issue['applied']=True
    basepath = output / 'baseline.docx'
    write(basepath, parts)
    tasks, unlocated = [], []
    for issue in issues:
        # Saved editors can contain the earlier long-form category labels.
        issue['category'] = category_label(issue.get('category'))
        status = '用户保留原文' if issue['decision']=='original' else '用户手动修改' if issue['decision']=='manual' and issue['applied'] else '已按建议修改' if issue['applied'] else '待人工确认，保留原文'
        note = '\n'.join(filter(None, ['问题类别：'+issue['category'], '问题：'+issue['id']+' · '+issue['title'],
            '问题说明：'+issue['reason'], '依据：'+issue['evidence'] if issue['evidence'] else '',
            '处理：'+status, '缺少材料：'+issue['missing'] if issue['missing'] else '',
            '定位或修改限制：'+issue['limitation'] if issue['limitation'] else '']))
        # A comment on an unrelated first paragraph falsely presents a valid
        # location. Keep unresolved findings in the report/editor, not the body.
        anchor=issue['paragraph_id']
        if anchor:
            tasks.append(dict(target_id=anchor, text=note))
        else:
            unlocated.append(issue['id'])
    if unlocated:
        warnings.append(f"{len(unlocated)} 项发现无法准确定位，未修改正文或添加正文批注：{'、'.join(unlocated)}。"
                        '问题及未修改原因保留在复核报告和结果列表中，请人工核对；其余已定位批注不受影响。')
    replacements = {}
    if tasks:
        with ZipFile(basepath) as z:
            add_layout_comments(z,revised,{key:(node,) for key,node in maps[0].items()},tasks,replacements)
    replacements['word/document.xml']=serialized(revised)
    # The submitted file may have hidden markup. Make native changes visible on open.
    if 'word/settings.xml' in parts:
        from lxml import etree as ET
        settings = xml(parts['word/settings.xml'])
        # CT_Settings orders revisionView/trackRevisions before protection/layout settings.
        preceding = {q(name) for name in ('writeProtection view zoom removePersonalInformation removeDateAndTime '
            'doNotDisplayPageBoundaries displayBackgroundShape printPostScriptOverText printFractionalCharacterWidth '
            'printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData mirrorMargins '
            'alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors '
            'hideGrammaticalErrors activeWritingStyle proofState formsDesign attachedTemplate linkStyles '
            'stylePaneFormatFilter stylePaneSortMethod documentType mailMerge').split()}
        view = settings.find(q('revisionView'))
        if view is None:
            view = ET.Element(q('revisionView'))
            settings.insert(next((i for i, node in enumerate(settings) if node.tag not in preceding), len(settings)), view)
        for key in ('markup', 'comments', 'insDel', 'formatting'):
            view.set(q(key), '1')
        tracking = settings.find(q('trackRevisions'))
        if tracking is None:
            tracking = ET.Element(q('trackRevisions'))
            settings.insert(settings.index(view) + 1, tracking)
        tracking.set(q('val'), '1')
        replacements['word/settings.xml'] = serialized(settings)
    write(output/'revision.docx', {**parts,**replacements})
    # Keep only prospectus content in the clean body. Review notes remain in
    # native comments, the separate report and the editor snapshot.
    for node in list(clean.iter()):
        if node.tag in (q('commentRangeStart'),q('commentRangeEnd'),q('commentReference')) and node.getparent() is not None:
            node.getparent().remove(node)
    cleanparts={**parts,'word/document.xml':serialized(clean)}
    # Remove orphaned comment parts and declarations in clean output.
    for name in list(cleanparts):
        if re.match(r'word/comments.*\.xml$', name):
            del cleanparts[name]
    for name in ('word/_rels/document.xml.rels','[Content_Types].xml'):
        root=xml(cleanparts[name])
        for node in list(root):
            if 'comments' in (node.get('Type','')+node.get('PartName','')).lower():
                root.remove(node)
        cleanparts[name]=serialized(root)
    write(output/'clean.docx', cleanparts)
    snapshot=dict(version='review-editor-v1',source_filename=request['filename'],source_sha256=sha,source_format=source.suffix.lower()[1:],warnings=warnings,paragraphs=paragraphs,issues=issues)
    (output/'editor.json').write_text(json.dumps(snapshot,ensure_ascii=False),encoding='utf8')
    return snapshot


if __name__ == '__main__':
    build(Path(sys.argv[1]),json.loads(Path(sys.argv[2]).read_text(encoding='utf8')),Path(sys.argv[3]))
